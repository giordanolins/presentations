﻿using System;

namespace Novo
{
    class Program
    {
        static void Main(string[] args)
        {
            var idade = 17;

            if(idade >= 18) {
                Console.WriteLine("Pode passar. Ta liberado!");
            }
            else {
                Console.WriteLine("Tá barrado muleke!");
            }
        }
    }
}
